#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>      //platform specific
#include<string.h>

#include<iostream>
using namespace std;

int main()
{
    cout<<"Jay Ganesh...\n";
    return 0;
}